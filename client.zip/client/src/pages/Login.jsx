function Login() {
  return (
    <div className="text-center py-20 text-4xl">
      Login Page
    </div>
  );
}

export default Login;