const Home = () => {
  return (
    <div className="bg-green-500 h-screen flex items-center justify-center">
      <h1 className="text-5xl font-bold text-white">
        Home Working ✅
      </h1>
    </div>
  );
};

export default Home;