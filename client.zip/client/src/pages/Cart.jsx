function Cart() {
  return (
    <div className="text-center py-20 text-4xl">
      Cart Page
    </div>
  );
}

export default Cart;