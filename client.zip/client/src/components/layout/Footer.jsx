const Footer = () => {
  return (
    <footer className="bg-slate-900 text-white py-6">
      <div className="max-w-7xl mx-auto text-center">
        © 2026 ShopHub. All Rights Reserved.
      </div>
    </footer>
  );
};

export default Footer;