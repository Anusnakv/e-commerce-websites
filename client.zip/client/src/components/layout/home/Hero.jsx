const Hero = () => {
  return (
    <section className="h-screen bg-slate-100 flex items-center justify-center">
      <div className="text-center">

        <h1 className="text-6xl font-bold mb-6">
          Discover Premium Fashion
        </h1>

        <p className="text-gray-600 text-lg mb-8">
          Shop the latest collections with modern style.
        </p>

        <button className="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition">
          Shop Now
        </button>

      </div>
    </section>
  );
};

export default Hero;