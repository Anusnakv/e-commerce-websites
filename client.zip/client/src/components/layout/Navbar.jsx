import { useState } from "react";
import { Link } from "react-router-dom";
import { FaShoppingCart, FaUser, FaBars, FaTimes } from "react-icons/fa";

function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

        <Link to="/" className="text-2xl font-bold text-indigo-600">
          ShopHub
        </Link>

        <div className="hidden md:flex gap-8">
          <Link to="/" className="hover:text-indigo-600">
            Home
          </Link>

          <Link to="/shop" className="hover:text-indigo-600">
            Shop
          </Link>

          <Link to="/cart" className="hover:text-indigo-600">
            Cart
          </Link>

          <Link to="/login" className="hover:text-indigo-600">
            Login
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-5">

          <FaShoppingCart
            size={20}
            className="cursor-pointer hover:text-indigo-600"
          />

          <FaUser
            size={20}
            className="cursor-pointer hover:text-indigo-600"
          />

        </div>

        <button
          className="md:hidden"
          onClick={() => setOpen(!open)}
        >
          {open ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-white px-6 pb-5 flex flex-col gap-4">

          <Link to="/" onClick={() => setOpen(false)}>
            Home
          </Link>

          <Link to="/shop" onClick={() => setOpen(false)}>
            Shop
          </Link>

          <Link to="/cart" onClick={() => setOpen(false)}>
            Cart
          </Link>

          <Link to="/login" onClick={() => setOpen(false)}>
            Login
          </Link>

        </div>
      )}
    </nav>
  );
}

export default Navbar;